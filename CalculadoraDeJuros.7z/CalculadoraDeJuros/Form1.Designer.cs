﻿namespace CalculadoraDeJuros
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValorPrincipal = new System.Windows.Forms.Label();
            this.txtValorPrincipal = new System.Windows.Forms.TextBox();
            this.txtTaxaAnual = new System.Windows.Forms.TextBox();
            this.lblTaxaJuros = new System.Windows.Forms.Label();
            this.txtNumeroParcelas = new System.Windows.Forms.TextBox();
            this.lblNumeroParcelas = new System.Windows.Forms.Label();
            this.btnResultado = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblValorPrincipal
            // 
            this.lblValorPrincipal.AutoSize = true;
            this.lblValorPrincipal.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblValorPrincipal.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorPrincipal.Location = new System.Drawing.Point(489, 75);
            this.lblValorPrincipal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblValorPrincipal.Name = "lblValorPrincipal";
            this.lblValorPrincipal.Size = new System.Drawing.Size(239, 19);
            this.lblValorPrincipal.TabIndex = 0;
            this.lblValorPrincipal.Text = "Valor Principal do Empréstimo";
            this.lblValorPrincipal.Click += new System.EventHandler(this.lblValorPrincipal_Click);
            // 
            // txtValorPrincipal
            // 
            this.txtValorPrincipal.Location = new System.Drawing.Point(532, 126);
            this.txtValorPrincipal.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtValorPrincipal.Name = "txtValorPrincipal";
            this.txtValorPrincipal.Size = new System.Drawing.Size(164, 26);
            this.txtValorPrincipal.TabIndex = 1;
            // 
            // txtTaxaAnual
            // 
            this.txtTaxaAnual.Location = new System.Drawing.Point(532, 247);
            this.txtTaxaAnual.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtTaxaAnual.Name = "txtTaxaAnual";
            this.txtTaxaAnual.Size = new System.Drawing.Size(164, 26);
            this.txtTaxaAnual.TabIndex = 3;
            // 
            // lblTaxaJuros
            // 
            this.lblTaxaJuros.AutoSize = true;
            this.lblTaxaJuros.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblTaxaJuros.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxaJuros.Location = new System.Drawing.Point(528, 194);
            this.lblTaxaJuros.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblTaxaJuros.Name = "lblTaxaJuros";
            this.lblTaxaJuros.Size = new System.Drawing.Size(163, 19);
            this.lblTaxaJuros.TabIndex = 2;
            this.lblTaxaJuros.Text = "Taxa de Juros Anual";
            // 
            // txtNumeroParcelas
            // 
            this.txtNumeroParcelas.Location = new System.Drawing.Point(532, 367);
            this.txtNumeroParcelas.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtNumeroParcelas.Name = "txtNumeroParcelas";
            this.txtNumeroParcelas.Size = new System.Drawing.Size(164, 26);
            this.txtNumeroParcelas.TabIndex = 5;
            // 
            // lblNumeroParcelas
            // 
            this.lblNumeroParcelas.AutoSize = true;
            this.lblNumeroParcelas.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblNumeroParcelas.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroParcelas.Location = new System.Drawing.Point(528, 314);
            this.lblNumeroParcelas.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNumeroParcelas.Name = "lblNumeroParcelas";
            this.lblNumeroParcelas.Size = new System.Drawing.Size(163, 19);
            this.lblNumeroParcelas.TabIndex = 4;
            this.lblNumeroParcelas.Text = "Número de Parcelas";
            // 
            // btnResultado
            // 
            this.btnResultado.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnResultado.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnResultado.Image = global::CalculadoraDeJuros.Properties.Resources.calculadora;
            this.btnResultado.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnResultado.Location = new System.Drawing.Point(493, 422);
            this.btnResultado.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(226, 55);
            this.btnResultado.TabIndex = 6;
            this.btnResultado.Text = "Calcular Juros";
            this.btnResultado.UseVisualStyleBackColor = false;
            this.btnResultado.Click += new System.EventHandler(this.btnResultado_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(489, 508);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 19);
            this.lblResultado.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 658);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.txtNumeroParcelas);
            this.Controls.Add(this.lblNumeroParcelas);
            this.Controls.Add(this.txtTaxaAnual);
            this.Controls.Add(this.lblTaxaJuros);
            this.Controls.Add(this.txtValorPrincipal);
            this.Controls.Add(this.lblValorPrincipal);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValorPrincipal;
        private System.Windows.Forms.TextBox txtValorPrincipal;
        private System.Windows.Forms.TextBox txtTaxaAnual;
        private System.Windows.Forms.Label lblTaxaJuros;
        private System.Windows.Forms.TextBox txtNumeroParcelas;
        private System.Windows.Forms.Label lblNumeroParcelas;
        private System.Windows.Forms.Button btnResultado;
        private System.Windows.Forms.Label lblResultado;
    }
}

